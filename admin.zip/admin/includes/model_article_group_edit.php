<?php 

?>



<div id="modal_delete" class="modal fade" role="dialog">
    <div class="modal-dialog">

         <!-- Modal content-->
        <div class="modal-content">
             <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Delete Account</h4>
            </div>

            <div class="modal-body" id="deleted_account_info" >                   
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Hủy bỏ</button>
                <button type="button" class="btn btn-success" id="ok-btn" data-dismiss="modal">Đồng ý</button>                
                
            </div>
        </div>
    </div>
</div>