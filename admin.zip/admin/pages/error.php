<div class="logo">
		<p>OOPS! - Could not Find it</p>
		<img src="images/404-1.png"/>
		<div class="sub">
		  <p><a href="?view=home">HOME </a></p>
		</div>
</div>
