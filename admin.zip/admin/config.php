<?php 
session_start();

define('HOST','localhost');
define('DBNAME','first_web_project');
define('USERNAME','root');
define('PASSWORD','');

define('AVATAR_PATH','images/avatars');
define('AVATAR_SIZE','0.25');
define('ARTICLE_PATH', 'images/articles');
define('ARTICLE_SIZE', '2.0');
define('PRODUCT_PATH', 'images/products');
define('PRODUCT_SIZE', '2.0');


date_default_timezone_set('Asia/Ho_Chi_Minh');

?>